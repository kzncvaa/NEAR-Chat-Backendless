
package services;

public class InvocationExample
{
    public static void main( String[] args )
    {
        NEAR.initApplication();

        NEAR nEAR = NEAR.getInstance();
        // invoke methods of you service
        //Object result = nEAR.yourMethod();
        //System.out.println( result );
    }
}
