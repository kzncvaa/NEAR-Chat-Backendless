
function getInfoByTransaction_ResultObject()
{
  
  this.transaction = null;
  
}
  